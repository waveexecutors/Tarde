package com.alexfriend.entity;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import java.util.Random;

/**
 * Friendly companion entity named Alex.
 * Features interactive right-click actions, automatic chat responses,
 * basic following AI, and custom animation support via the model.
 * Fully SFW friendly interactions.
 */
public class EntityAlexFriend extends EntityCreature {

    private int interactionIndex = 0;
    private int chatCooldown = 0;
    private static final String[] GREETINGS = {
            "Hi there! I'm Alex, your friend. Ready for an adventure?",
            "Hey! It's so nice to see you again.",
            "Hello friend! What should we do today?"
    };

    private static final String[][] INTERACTIONS = {
            // Action 0: Friendly chat
            {
                    "I really enjoy spending time with you.",
                    "The world feels brighter when you're around!",
                    "Tell me about your latest builds. I love hearing about them."
            },
            // Action 1: Encouragement
            {
                    "You're doing great! Keep exploring.",
                    "I believe in you. You can handle anything.",
                    "Need help with anything? Just ask!"
            },
            // Action 2: Fun / playful
            {
                    "Want to race to that hill over there?",
                    "I found a cool flower earlier. Nature is amazing!",
                    "Let's go mining together sometime!"
            },
            // Action 3: Caring
            {
                    "Have you eaten recently? Don't forget to take care of yourself.",
                    "Rest if you need to. I'll keep watch.",
                    "You're my favorite person in this world."
            },
            // Action 4: Observation
            {
                    "Look at those clouds! They look soft today.",
                    "I like how the sunlight hits the grass here.",
                    "This place feels peaceful with you nearby."
            }
    };

    private static final String[] AFTER_ACTION = {
            "That was fun!",
            "Thanks for chatting with me.",
            "I feel happier already.",
            "You're the best friend!",
            "Let's do that again soon."
    };

    public EntityAlexFriend(World worldIn) {
        super(worldIn);
        this.setSize(0.6F, 1.8F);
        this.experienceValue = 0;
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIPanic(this, 1.25D));
        this.tasks.addTask(2, new EntityAIWanderAvoidWater(this, 0.8D));
        this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(4, new EntityAILookIdle(this));
        // Mild follow behavior can be added by checking distance in onLivingUpdate
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.28D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
        this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(0.4D);
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (!this.world.isRemote && hand == EnumHand.MAIN_HAND) {
            if (chatCooldown <= 0) {
                performInteraction(player);
                chatCooldown = 40; // ~2 seconds cooldown
            } else {
                player.sendMessage(new TextComponentString(
                        TextFormatting.GRAY + "[Alex] " + TextFormatting.WHITE + "Give me a moment..."
                ));
            }
            return true;
        }
        return super.processInteract(player, hand);
    }

    private void performInteraction(EntityPlayer player) {
        Random rand = this.rand;

        // Cycle through interaction categories
        int category = interactionIndex % INTERACTIONS.length;
        String[] lines = INTERACTIONS[category];
        String response = lines[rand.nextInt(lines.length)];

        // Send main response
        player.sendMessage(new TextComponentString(
                TextFormatting.GREEN + "[Alex] " + TextFormatting.WHITE + response
        ));

        // Follow-up chat after a short delay simulation (immediate second line for simplicity)
        String after = AFTER_ACTION[rand.nextInt(AFTER_ACTION.length)];
        player.sendMessage(new TextComponentString(
                TextFormatting.GREEN + "[Alex] " + TextFormatting.AQUA + after
        ));

        // Occasional greeting if first interactions
        if (interactionIndex < 3 && rand.nextFloat() < 0.4F) {
            String greet = GREETINGS[rand.nextInt(GREETINGS.length)];
            player.sendMessage(new TextComponentString(
                    TextFormatting.GREEN + "[Alex] " + TextFormatting.YELLOW + greet
            ));
        }

        // Play a soft sound
        this.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.4F, 1.6F + rand.nextFloat() * 0.3F);

        interactionIndex++;
        // Make her look at the player
        this.getLookHelper().setLookPositionWithEntity(player, 30.0F, 30.0F);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (chatCooldown > 0) {
            chatCooldown--;
        }

        // Simple gentle follow if player is nearby and not too close
        if (!this.world.isRemote) {
            EntityPlayer nearest = this.world.getClosestPlayerToEntity(this, 16.0D);
            if (nearest != null && this.getDistance(nearest) > 4.0D && this.getDistance(nearest) < 12.0D) {
                this.getNavigator().tryMoveToEntityLiving(nearest, 0.9D);
            }
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return null; // No default ambient to keep clean; interactions provide feedback
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSourceIn) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    @Override
    public boolean canBeLeashedTo(EntityPlayer player) {
        return true;
    }

    @Override
    public boolean isChild() {
        return false;
    }

    // Data for animations / state can be extended later with DataParameter if needed
}
