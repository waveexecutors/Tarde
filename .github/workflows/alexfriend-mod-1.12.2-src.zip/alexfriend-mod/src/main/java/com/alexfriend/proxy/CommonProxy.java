package com.alexfriend.proxy;

import com.alexfriend.init.ModEntities;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy {

    public void preInit(FMLPreInitializationEvent event) {
        ModEntities.register();
    }

    public void init(FMLInitializationEvent event) {
        // Common init
    }

    public void postInit(FMLPostInitializationEvent event) {
        // Common post
    }
}
