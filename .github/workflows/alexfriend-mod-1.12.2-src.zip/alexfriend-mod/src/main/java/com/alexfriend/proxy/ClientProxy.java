package com.alexfriend.proxy;

import com.alexfriend.client.RenderAlexFriend;
import com.alexfriend.entity.EntityAlexFriend;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        RenderingRegistry.registerEntityRenderingHandler(EntityAlexFriend.class, new IRenderFactory<EntityAlexFriend>() {
            @Override
            public Render<? super EntityAlexFriend> createRenderFor(RenderManager manager) {
                return new RenderAlexFriend(manager);
            }
        });
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
    }
}
