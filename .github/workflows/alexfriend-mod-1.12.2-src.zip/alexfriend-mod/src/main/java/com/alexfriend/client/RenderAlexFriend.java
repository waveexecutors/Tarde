package com.alexfriend.client;

import com.alexfriend.AlexFriend;
import com.alexfriend.entity.EntityAlexFriend;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderAlexFriend extends RenderLiving<EntityAlexFriend> {

    private static final ResourceLocation TEXTURE = new ResourceLocation(AlexFriend.MODID, "textures/entity/alex.png");

    public RenderAlexFriend(RenderManager renderManagerIn) {
        super(renderManagerIn, new ModelAlexFriend(), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityAlexFriend entity) {
        return TEXTURE;
    }
}
