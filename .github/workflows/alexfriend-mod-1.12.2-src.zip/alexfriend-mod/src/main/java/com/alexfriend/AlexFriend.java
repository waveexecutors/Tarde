package com.alexfriend;

import com.alexfriend.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;

@Mod(modid = AlexFriend.MODID, name = AlexFriend.NAME, version = AlexFriend.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class AlexFriend {

    public static final String MODID = "alexfriend";
    public static final String NAME = "Alex Friend";
    public static final String VERSION = "1.0.0";

    @Mod.Instance
    public static AlexFriend instance;

    @SidedProxy(clientSide = "com.alexfriend.proxy.ClientProxy", serverSide = "com.alexfriend.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static Logger logger;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        logger.info("Alex Friend pre-initialization started.");
        proxy.preInit(event);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        logger.info("Alex Friend initialization.");
        proxy.init(event);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        logger.info("Alex Friend post-initialization complete.");
        proxy.postInit(event);
    }
}
