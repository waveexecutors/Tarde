package com.alexfriend.client;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Custom model based on biped/Alex proportions with:
 * - Front hair bangs (Jenny-inspired style adapted for Alex)
 * - Animated blinking eyelids for a cute face
 * - Enhanced idle head movement and walking bounce
 * Green eyes are handled via texture UV.
 */
@SideOnly(Side.CLIENT)
public class ModelAlexFriend extends ModelBiped {

    public ModelRenderer frontHairLeft;
    public ModelRenderer frontHairRight;
    public ModelRenderer frontHairMiddle;
    public ModelRenderer leftEyelid;
    public ModelRenderer rightEyelid;

    private float blinkTimer = 0.0F;
    private boolean isBlinking = false;

    public ModelAlexFriend() {
        this(0.0F, false);
    }

    public ModelAlexFriend(float modelSize, boolean smallArms) {
        super(modelSize, 0.0F, 64, 64);

        // Front hair bangs - positioned over the forehead like Jenny-style bangs but for Alex
        this.frontHairMiddle = new ModelRenderer(this, 32, 0);
        this.frontHairMiddle.addBox(-2.0F, -8.5F, -4.6F, 4, 3, 1, modelSize);
        this.frontHairMiddle.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.bipedHead.addChild(this.frontHairMiddle);

        this.frontHairLeft = new ModelRenderer(this, 32, 4);
        this.frontHairLeft.addBox(-4.0F, -8.0F, -4.4F, 2, 4, 1, modelSize);
        this.frontHairLeft.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.bipedHead.addChild(this.frontHairLeft);

        this.frontHairRight = new ModelRenderer(this, 38, 4);
        this.frontHairRight.addBox(2.0F, -8.0F, -4.4F, 2, 4, 1, modelSize);
        this.frontHairRight.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.bipedHead.addChild(this.frontHairRight);

        // Simple eyelid planes for blink animation (overlay on eyes)
        // Eyes are typically at UV around 8-12 for left, etc. We use small boxes that cover eyes when rotated
        this.leftEyelid = new ModelRenderer(this, 0, 0);
        this.leftEyelid.addBox(-3.5F, -5.5F, -4.15F, 2, 1, 0.2F, modelSize);
        this.leftEyelid.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.bipedHead.addChild(this.leftEyelid);

        this.rightEyelid = new ModelRenderer(this, 0, 0);
        this.rightEyelid.addBox(1.5F, -5.5F, -4.15F, 2, 1, 0.2F, modelSize);
        this.rightEyelid.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.bipedHead.addChild(this.rightEyelid);

        // Ensure slim arms for Alex-like proportions if desired
        // (ModelBiped already supports via constructor, but we keep default for compatibility)
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);

        // Cute idle head sway
        float idleSway = MathHelper.sin(ageInTicks * 0.05F) * 0.03F;
        this.bipedHead.rotateAngleZ = idleSway;
        this.bipedHeadwear.rotateAngleZ = idleSway;

        // Walking bounce / hip sway enhancement
        float walkBounce = MathHelper.abs(MathHelper.sin(limbSwing * 0.6662F)) * limbSwingAmount * 0.08F;
        this.bipedBody.rotationPointY = 0.0F + walkBounce * 2.0F;

        // Blink animation - every ~4-6 seconds, quick blink
        blinkTimer += 0.05F;
        if (blinkTimer > 4.5F + (entityIn.getEntityId() % 20) * 0.1F) {
            isBlinking = true;
            if (blinkTimer > 4.7F) {
                blinkTimer = 0.0F;
                isBlinking = false;
            }
        }

        float eyelidClose = isBlinking ? 0.9F : 0.0F;
        this.leftEyelid.rotateAngleX = eyelidClose;
        this.rightEyelid.rotateAngleX = eyelidClose;

        // Slight front hair movement with head
        this.frontHairMiddle.rotateAngleX = this.bipedHead.rotateAngleX * 0.1F;
        this.frontHairLeft.rotateAngleX = this.bipedHead.rotateAngleX * 0.15F;
        this.frontHairRight.rotateAngleX = this.bipedHead.rotateAngleX * 0.15F;
    }
}
