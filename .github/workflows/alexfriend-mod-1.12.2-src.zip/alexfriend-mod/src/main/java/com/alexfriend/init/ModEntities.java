package com.alexfriend.init;

import com.alexfriend.AlexFriend;
import com.alexfriend.entity.EntityAlexFriend;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class ModEntities {

    private static int entityId = 0;

    public static void register() {
        registerEntity("AlexFriend", EntityAlexFriend.class, 80, 3, true, 0x55FF55, 0x33AAFF);
    }

    private static void registerEntity(String name, Class<? extends Entity> entityClass, int trackingRange, int updateFrequency, boolean sendsVelocityUpdates, int eggPrimary, int eggSecondary) {
        EntityRegistry.registerModEntity(
                new ResourceLocation(AlexFriend.MODID, name.toLowerCase()),
                entityClass,
                name,
                entityId++,
                AlexFriend.instance,
                trackingRange,
                updateFrequency,
                sendsVelocityUpdates,
                eggPrimary,
                eggSecondary
        );
    }
}
