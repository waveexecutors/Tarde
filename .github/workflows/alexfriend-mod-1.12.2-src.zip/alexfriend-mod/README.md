# Alex Friend - Minecraft Forge 1.12.2 Mod

A friendly companion mod that adds **Alex**, a custom interactive NPC.

## Features

- **Spawn Egg**: Available in Creative mode inventory (search "Alex" or look under Spawn Eggs). Primary color green, secondary cyan.
- **Cute Animated Face**: Custom model with blinking eyelids and idle head sway.
- **Front Hair**: Jenny-inspired bangs adapted for an Alex-style appearance.
- **Green Eyes**: Texture includes green irises.
- **Cool Walking / Idle Animations**: Enhanced limb swing, body bounce on walk, and subtle hair movement.
- **Right-Click Interactions**: Multiple categories of friendly dialogue (chat, encouragement, playful, caring, observation). Cycles automatically.
- **Automatic Chat Responses**: After every interaction Alex replies in chat with colored messages, similar in style to popular companion mods (SFW only).
- **Gentle Follow**: She will slowly walk toward a nearby player when within range.
- **Fully SFW**: All interactions are friendly and appropriate. No romantic or adult content.

## Building

This source is prepared for GitHub Actions.

1. Place the extracted contents as the project root (or extract the provided ZIP).
2. Ensure Java 8 is available for the classic ForgeGradle 2.3 toolchain.
3. Run:

```bash
./gradlew setupDecompWorkspace
./gradlew build
```

The resulting JAR will be in `build/libs/alexfriend-1.0.0.jar`.

## GitHub Actions

Use the separate `build.yml` workflow. It is designed to download this ZIP (or use the repository contents), extract if needed, and produce the mod JAR as an artifact.

## Notes

- Texture is a simple procedural base. You may replace `assets/alexfriend/textures/entity/alex.png` with a higher-quality 64x64 player-style skin (keep UV layout compatible).
- Entity registration uses the classic `EntityRegistry.registerModEntity` with spawn egg colors.
- Model extends `ModelBiped` with additional `ModelRenderer` children for hair and eyelids.
- Compatible with Forge 1.12.2 (recommended 14.23.5.2847).

Enjoy your new friend Alex!
